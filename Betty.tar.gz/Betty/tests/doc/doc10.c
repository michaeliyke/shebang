/**
 * first - Called before main
 */
void __attribute__((constructor)) first(void)
{
	printf("test\n");
}

/**
 * first - Called before main
 */
void __attribute__ ((constructor)) first(void)
{
	printf("test\n");
}

/**
 * first - Called before main
 */
void __attribute__((constructor))first(void)
{
	printf("test\n");
}
