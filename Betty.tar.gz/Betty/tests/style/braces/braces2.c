int func0(void)
{
	if (1)
		return (1);
	else if (2)
		return (2);
	else
		return (0);
	while (1)
		return (1);
	for (; 1;)
		return (1);
}
