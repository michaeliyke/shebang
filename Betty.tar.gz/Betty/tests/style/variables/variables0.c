int i;
int global_var;
	int indented_global = 98;
unsigned int another = 12;
void (*global_func_ptr)(int, int);

int test_func(int some_var,
	int (*func)(int),
	test_t *some_other)
{
	return (0);
}
