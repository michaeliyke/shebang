int func0(void)
{
    return (0);
}

int func1(void)
{
	return (0);
}
