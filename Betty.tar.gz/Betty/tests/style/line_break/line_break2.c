#include <stdio.h>

/**
 * main - Entry point
 *
 * Return: Always 0 (Success)
 */
int main(void)
{
	printf("hello"); /* a =
	12; return a; */
	printf("hello"); /* a = 12; return a;*/
	printf("hello"); a = 12; return a;
}

int func(void)
{
	int i = 0;

	if (i != 3)
	{
		_putchar('E'); _putchar('r'); _putchar('r'); _putchar('o');
		_putchar('r'); _putchar('\n'); exit(98);
	}

	return (0);
}
