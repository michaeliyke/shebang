int main(void)
{
	int a;

	a = 0; /* Valid comment */
	return (a);
}
